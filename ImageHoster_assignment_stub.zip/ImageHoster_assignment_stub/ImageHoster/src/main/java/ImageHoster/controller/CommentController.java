package ImageHoster.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import ImageHoster.model.Comment;
import ImageHoster.model.Image;
import ImageHoster.model.User;
import ImageHoster.service.CommentService;
import ImageHoster.service.ImageService;

@Controller
public class CommentController {
	
    @Autowired
    private ImageService imageService;
    
    @Autowired
    private CommentService commentService;
    
    @Autowired
    private ImageController imageController;
	
	@RequestMapping(value = "/image/{imageId}/{imageTitle}/comments", method = RequestMethod.POST)
	private String createComment(@PathVariable("imageId") Integer imageId, @PathVariable("imageTitle") String title, HttpSession session, Model model) {
		Image image = imageService.getImage(imageId);
		Comment comment = new Comment();
		comment.setImage(image);
		comment.setUser((User) session.getAttribute("loggeduser"));
		commentService.createComment(comment);
		model.addAttribute("comment", comment);
		return imageController.showImage(imageId, model);
		
	}
}
