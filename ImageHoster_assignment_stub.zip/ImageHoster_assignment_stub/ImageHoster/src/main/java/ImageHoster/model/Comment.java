package ImageHoster.model;

import java.time.LocalDate;

import javax.persistence.*;

@Entity
@Table(name = "comments")
public class Comment {
	
	@Id
	@Column(name = "id")
	int id;
	
	@Column(name = "text", length = 256, columnDefinition = "text-based data")
	String text;
	
	@Column(name = "createdDate")
	LocalDate createdDate;
	
	@OneToMany
	@Column(name = "user")
	User user;
	
	@OneToMany
	@Column(name = "image")
	Image image;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Image getImage() {
		return image;
	}

	public void setImage(Image image) {
		this.image = image;
	}
	
}
